# DN Company ERP - Firebase Ready

## First login
Click **Create default admin first**, then login:
- admin@dncompany.kr
- DN@2026Admin

## Run locally
npm install
npm run dev

## Deploy
npm install -g firebase-tools
firebase login
firebase use dncompany-f254d
npm install
npm run deploy

Live URL after deploy:
https://dncompany-f254d.web.app
